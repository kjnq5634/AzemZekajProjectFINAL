# ELEC2645 Unit 2 Project Template

### 1 Main menu
The main menu provides the user with 3 options 1. Calculator 2.Signal Generator 3.Exit
### 2 Functions
a. Calculator 
This allows for 3 suboptions
  # 1 Arithmetic calculator
  i.e add,subtract,multiply,divide.
  when "=" is pressed the answer will be stored in ANS which can be used later to operate on the most recent result.
  # 2 Non Linear Calculator
  this does the main non linear function i.e sin,cos,tan,cosec,sec,cot,e,log(natural log as it is the base log on C).
  this also allows ANS storage
  # 3 Matrix Calculator
  this allows many matrix manipulating functions like addition,subtraction,element wise multiplication, finding determinants,inverses of 2x2 and 3x3 matrices , the transpose of them and division.
b. Signal Generator:
   This provides the user with the option to generate signals as a png, they can manipulate the amplitude,frequency and the sampling rate of the graph.
   This allows for a Sinusodial,Triangle wave, Square wave and a Saw tooth wave.
   Thank you hope the program can be of use to you.
   